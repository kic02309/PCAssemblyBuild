// ATmega32U4 Pro Micro. USB serial only. Buttons connect each pin to GND.
const byte buttonPins[8] = {2,3,4,5,6,7,8,9};
const byte shiftPin = 10;
const char normalKeys[] = "12345678";
const char shiftKeys[] = "QWERTYUI";
const unsigned long debounceMs = 30;
const unsigned long leaseMs = 2000;

struct DebouncedInput {
  byte pin;
  bool raw;
  bool stable;
  unsigned long changed;

  void begin(byte number) {
    pin = number;
    pinMode(pin, INPUT_PULLUP);
    raw = stable = digitalRead(pin) == LOW;
    changed = millis();
  }
  bool pressed(unsigned long now) {
    const bool value = digitalRead(pin) == LOW;
    if (value != raw) { raw = value; changed = now; }
    if (raw == stable || now - changed < debounceMs) return false;
    stable = raw;
    return stable;
  }
};
DebouncedInput buttons[8], shiftButton;
char nonce[17] = {};
char input[24] = {};
byte used = 0;
bool overflow = false;
unsigned long sequence = 0, lastHello = 0;

void readHost() {
  for (byte i = 0; i < 32 && Serial.available(); ++i) {
    const char c = Serial.read();
    if (c == '\r') continue;
    if (c != '\n') {
      if (used < sizeof(input)-1) input[used++] = c;
      else overflow = true;
      continue;
    }
    input[used] = '\0';
    if (!overflow && used == 22 && strncmp(input, "HELLO ", 6) == 0 &&
        strspn(input + 6, "0123456789abcdef") == 16) {
      if (strcmp(nonce, input + 6) != 0) {
        strcpy(nonce, input + 6);
        sequence = 0;
      }
      lastHello = millis();
      Serial.print(F("PCAL1 ")); Serial.print(nonce); Serial.println(F(" READY"));
    }
    used = 0;
    overflow = false;
  }
}
void setup() {
  Serial.begin(115200);
  for (byte i = 0; i < 8; ++i) buttons[i].begin(buttonPins[i]);
  shiftButton.begin(shiftPin);
}
void loop() {
  if (Serial) readHost();
  else { nonce[0] = '\0'; used = 0; overflow = false; }
  const unsigned long now = millis();
  shiftButton.pressed(now);
  for (byte i = 0; i < 8; ++i) {
    if (!buttons[i].pressed(now)) continue;
    if (!Serial || !nonce[0] || now - lastHello >= leaseMs) continue;
    Serial.print(F("PCAL1 ")); Serial.print(nonce); Serial.print(' ');
    Serial.print(++sequence); Serial.print(' ');
    Serial.println(shiftButton.stable ? shiftKeys[i] : normalKeys[i]);
  }
}
